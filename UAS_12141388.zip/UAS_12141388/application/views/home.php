<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('header');

echo "INI YANG HARUS DIGANTI";

$this->load->view('footer');
?>